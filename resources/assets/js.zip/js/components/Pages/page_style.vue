<template lang="pug">
.page
  section.sectionHero.theme.white(style="display: block")
    .container
      h1 h1 Text Lorem, ipsum dolor.
      h2 h2 Text Lorem, ipsum dolor.
      h3 h3 Text Lorem, ipsum dolor.
      h4 h4 Text Lorem, ipsum dolor.
      h5 h5 Text Lorem, ipsum dolor.
      h6 h6 Text Lorem, ipsum dolor.
      p Lorem ipsum dolor sit amet consectetur adipisicing elit. Eveniet quia corrupti eligendi repudiandae odio, saepe minus quos ea molestiae aliquid itaque at, odit neque ducimus aliquam. Quasi et eum expedita.
      hr
      .btn.orange Orange Btn
      .btn.blue Blue Btn
      .btn.grey.outline Blue Btn
</template>

<script>
export default {

}
</script>

<style>

</style>
