<template>
<div class="page_loading">
  <div class="bigd"></div>
</div>
</template>

<script>
export default {
}
</script>
<style>
.ec685184-f611-44a6-93b0-55957dc715d0{fill:#fff;}
</style>