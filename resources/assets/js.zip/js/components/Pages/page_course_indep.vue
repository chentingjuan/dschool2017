<template lang="pug">
.page.page_course
  section.sectionHero.blue
    //- h1 學院課程
    img.coverGraphic(src="/img/hero_course_cover.svg")
</template>

<script>
export default {

}
</script>

<style>

</style>
