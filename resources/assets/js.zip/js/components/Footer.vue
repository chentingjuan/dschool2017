<template lang="pug">
.footer
  footer
    .container
      .row
        .col-sm-3
          img(src="/img/index__pageLogoOrange.svg", width="80px")
          h3 台大創新設計學院
          h4 D-School@NTU
          a(href="https://www.facebook.com/ntudschool/" target="_blank")
            i.fa.fa-facebook-square
        .col-sm-9
          ul
            li 
              span.l 地址
              span 10087 台北市中正區思源街18號卓越研究大樓四樓
            li 
              span.l 電話
              span 02-3366-1869
            li 
              span.l 信箱
              span ntudschool@ntu.edu.tw
  
</template>

<script>
export default {

}
</script>

<style>

</style>
