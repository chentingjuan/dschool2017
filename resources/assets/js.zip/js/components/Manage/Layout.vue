<template lang="pug">
.container-fluid
  .row
    .col-sm-2
      //h1 管理總介面
      ul.list-group
        li.list-item 測試


    .col-sm-10
      router-view
</template>

<script>
export default {

}
</script>

<style>

</style>
